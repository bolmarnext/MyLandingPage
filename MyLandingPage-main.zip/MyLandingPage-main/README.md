# My Landing Page
<h2>What is Landing Page?</h2>
<p>Answer:</p>
Project type: Solo Project
